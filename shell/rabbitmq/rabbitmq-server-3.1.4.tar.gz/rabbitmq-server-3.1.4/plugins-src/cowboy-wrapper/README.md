Cowboy requires R14
