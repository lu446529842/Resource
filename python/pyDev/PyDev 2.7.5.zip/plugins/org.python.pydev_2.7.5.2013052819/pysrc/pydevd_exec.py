def Exec(exp, global_vars, local_vars):
    exec exp in global_vars, local_vars